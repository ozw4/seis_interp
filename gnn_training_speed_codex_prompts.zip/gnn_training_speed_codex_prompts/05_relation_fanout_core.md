# Codex 実装プロンプト 05 — pure NumPy relation-wise fixed-fanout sampler


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 目的

visibility 適用済みの deterministic candidate neighbors から、destination ごと・relation ごとに最大 F 辺を一様に非復元抽出する pure NumPy 関数を追加する。この工程では config、trainer、subgraph builder へ接続しない。

## 主な対象

- 新規候補: `src/seis_interp/processing/trace_graph_edge_sampling.py`
- `src/seis_interp/processing/trace_graph_neighbors.py` の `TraceGraphNeighbors`
- 新規候補: `tests/unit/test_trace_graph_edge_sampling.py`

`utils.py` へ置かない。

## API 契約

責務が一つの関数を実装する。名前は現在の命名に合わせてよいが、概念上は次。

```python
def sample_trace_graph_relation_fanout(
    neighbors: TraceGraphNeighbors,
    *,
    fanout_per_relation: int,
    rng: np.random.Generator,
) -> TraceGraphNeighbors:
    ...
```

### 入力

- `neighbors`: すでに visibility、allowed mask、self exclusion、radius、candidate top-K が適用された edge。
- `fanout_per_relation`: positive integer F。
- `rng`: caller が所有する `np.random.Generator`。関数内で seed しない。

### 出力

各 `(destination_id, edge_type)` group について、

- edge 数が F 以下なら全 edge を残す。
- F より大きければ一様に F index を replacement なしで選ぶ。
- 選択後は入力中の元の順序へ戻す。

入力 `TraceGraphNeighbors` は destination、relation、distance、ID 順であるため、出力は入力の subsequence とし、その安定順序を維持する。これにより downstream の node ordering と reproducibility を不要に変えない。

### validation

- `fanout_per_relation` は bool を拒否し、positive integer のみ。
- `rng` は `np.random.Generator` であることを明確に要求する。
- 4 array の長さ、shape、dtype が不整合なら明確な error。
- edge type の有効範囲は既存 topology 契約に従う。ここで multi-relation config validation を重複実装しない。
- empty input を正しく返す。
- 入力 array を変更しない。
- output dtype は sender/destination/type=`int64`、distance=`float64`。

relation ごとの異なる fanout mapping、distance-weighted sampling、replacement sampling は追加しない。

## 乱数契約

- 同じ candidate arrays と同じ初期 seed の generator は同じ output。
- generator state は実際の抽出に応じて前進する。
- function 内で `np.random.default_rng(...)` を作らない。
- edge 数が F 以下の group で不要な乱数を消費しない。これを test で固定し、将来 candidate density が変わったときの乱数系列を予測可能にする。

## テスト要件

最低限、次を含める。

1. 複数 destination × 4 relation。
2. 各 group の output count が `min(input_count, F)`。
3. replacement なし、duplicate edge なし。
4. output は input の subsequence で順序を維持。
5. same seed reproducibility。
6. known candidate fixture で different seed が異なる subset を返す。
7. count <= F の group は全保持。
8. empty edges。
9. invalid F、invalid dtype/shape。
10. input arrays が不変。
11. zero-weight edge を作らず、実際に array length が減る。

確率的にまれな一致で flaky にならない fixture/seed を固定して使う。

## 非目標

- `FixedTraceGraphSubgraphBuilder` への接続
- BFS/closure の変更
- YAML config
- torch tensor sampling
- GPU sampling
- per-relation mapping
- sampling statistics framework

## 実行する確認

```bash
ruff check .
ruff format --check .
pytest   tests/unit/test_trace_graph_edge_sampling.py   tests/unit/test_trace_graph_neighbors.py
```

## 受入条件

- small pure function で independently test できる。
- destination/relation ごとに F を保証する。
- stable edge ordering を維持する。
- caller-owned RNG 以外の乱数源を使わない。
