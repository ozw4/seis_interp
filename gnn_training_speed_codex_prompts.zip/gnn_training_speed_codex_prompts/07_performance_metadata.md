# Codex 実装プロンプト 07 — 速度比較用 training profile と resource metadata


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 依存

工程01〜06が完了し、history に subgraph count、batch preparation time、optimization time があること。

## 目的

run ごとに static-index、AMP、fanout の効果を比較できるよう、既存の training history から小さい集計を作り、run metadata と final checkpoint provenance へ追加する。既存の full history と metadata key は維持する。

## 主な対象

- `src/seis_interp/training/relational_trace_graph_poc_trainer.py`
- 新規候補: `src/seis_interp/training/trace_graph_training_profile.py`
- `src/seis_interp/pipelines/interpolate_relational_trace_graph.py`
- `src/seis_interp/training/relational_trace_graph_checkpoints.py`
- `docs/relational_trace_graph.md`
- run metadata/checkpoint/pipeline tests

pipeline に集計ロジックを直接増やしすぎない。複数の key を計算するなら training module の pure function にする。

## 集計契約

既存 history を入力に、JSON-compatible な Python `int`/`float` だけで最低限次を出す。

```text
optimizer_updates
mean_recorded_step_seconds
mean_batch_preparation_seconds
mean_optimization_seconds
mean_subgraph_node_count
max_subgraph_node_count
mean_subgraph_support_node_count
mean_subgraph_edge_count
max_subgraph_edge_count
mean_subgraph_max_depth
```

pipeline で実測する `training_seconds` を使い、次も resources に加える。

```text
optimizer_updates_per_second
training_peak_cuda_allocated_bytes
training_peak_cuda_reserved_bytes
```

- `optimizer_updates_per_second = steps_completed / training_seconds`
- CUDA peak は training 完了直後、prediction 開始前に読み取る。
- CPU の CUDA field は追加しないか `None` ではなく、既存 metadata 方針に合わせて明示的に省略する。
- empty history は通常到達しないが pure aggregation boundary では明確な error にする。
- NaN/inf を metadata へ書かない。
- percentile、histogram、per-relation mapping は今回追加しない。

### metadata 配置

既存 `resources.training_seconds` は残す。

推奨配置は次。

```text
metadata["training_profile"] = <集計>
metadata["resources"]["optimizer_updates_per_second"] = ...
metadata["resources"]["training_peak_cuda_allocated_bytes"] = ...
metadata["resources"]["training_peak_cuda_reserved_bytes"] = ...
```

既存の `metadata["training"] = asdict(trained)` は削除しない。

### training mode provenance

final checkpoint metadata と run metadata から、少なくとも次を確認できるようにする。

```text
mixed_precision
edge_sampling  # null/absent or mapping with seed and fanout_per_relation
```

これらは training-only provenance であり、model constructor、`TraceGraphSettings`、checkpoint load 時の推論必須設定にはしない。

resolved config が正本であることを維持しつつ、standalone final checkpoint の provenance にも mode を残す。既存 checkpoint key を変更・削除しない。

## 実装要件

1. aggregation は pure function とし、history を変更しない。
2. `statistics` など標準 library だけで十分なら NumPy 依存処理を増やさない。
3. CUDA training peak は、既存の `reset_peak_memory_stats` から training 終了までの区間を測る。prediction 後に読む end-to-end peak と混同しない。
4. metadata の数値は machine-readable full precision。人向け表示でのみ丸める。
5. `poc_compute_metadata(...)` の既存共通比較契約を壊さない。
6. `schema_version` を追加しない。
7. run identity、loss、normalization、coverage、final checkpoint role を変更しない。

## テスト要件

1. synthetic history の正しい mean/max/throughput。
2. input history を変更しない。
3. empty/non-finite/欠損 key の明確な error。
4. CPU pipeline metadata に `training_profile` と throughput が入り、CUDA-only fields の方針が一貫する。
5. CUDA 利用可能時は training peak fields が nonnegative integer。
6. mixed precision と edge sampling の enabled/disabled provenance。
7. checkpoint load は新しい provenance を推論引数として要求しない。
8. existing metadata、compute、coverage keys が残る。
9. JSON serialization が成功する。
10. strict expected-dict tests を必要な範囲だけ更新する。

## 文書更新

`docs/relational_trace_graph.md` の training/runtime section に次を短く記載する。

- geometry-only index は run 内で再利用される。
- `mixed_precision` の accepted values と unsupported-device error。
- `edge_sampling` の candidate K と fanout F の違い。
- sampling は training only、prediction は full K。
- `training_profile`/resource fields の定義。
- timing は同一 machine/process 条件での相対比較用。

実装履歴や PR 説明は書かず、現在の契約だけを書く。

## 非目標

- benchmark dashboard
- CSV exporter
- profiler trace
- TensorBoard/W&B
- performance threshold の自動判定
- study config 作成
- full history の削除/圧縮

## 実行する確認

```bash
ruff check .
ruff format --check .
pytest   tests/unit/test_relational_trace_graph_poc.py   tests/unit/test_relational_trace_graph_trainer.py   tests/unit/test_relational_trace_graph_checkpoints.py   tests/unit/test_run_c3_random80_poc.py
```

新しい pure helper の test file を追加した場合も実行する。

## 受入条件

- run metadata だけで updates/s、step 内訳、平均/最大 node-edge 数、training peak memory を比較できる。
- AMP/fanout mode が run と final checkpoint の provenance に残る。
- inference はその設定に依存しない。
- 既存 metadata 契約を削除していない。
