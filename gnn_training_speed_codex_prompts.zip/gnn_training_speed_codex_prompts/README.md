# Relational Trace GNN 学習高速化 — Codex 実装プロンプト集

対象: `ozw4/seis_interp`  
参照スナップショット: `main@5829a11482edd8adafd29b4be25f910fe5545425`

## 目的

次の形へ段階的に移行し、各変更の効果を独立に検証できるようにする。

```text
fixed geometry
    -> run-lifetime static spatial index
    -> pseudo-masked target query batch
    -> target-centered L-hop dependency subgraph
    -> per-relation random fixed fanout
    -> AMP model step
    -> target-only loss
```

## 現在の実装を踏まえた判断

参照スナップショットでは、次はすでに存在する。

- `compute_trace_graph_geometry(...)` は学習呼び出し内で一度だけ実行される。
- `FixedTraceGraphSubgraphBuilder` は episode ごとに作られ、episode 内では観測 trace の近傍をキャッシュする。
- query target を起点に `message_passing_rounds` 分だけ依存 closure を構築し、query だけで loss を計算する処理は実装済みである。
- 近傍は可視性を適用した後に relation ごとの決定論的 top-K として選ばれる。
- AMP と学習時 edge sampling は未実装である。

したがって、target-centered subgraph を別方式で作り直さない。既存 tensor 契約を維持し、PyG の `Data`、`NeighborLoader` なども導入しない。

## 固定する設計判断

1. **キャッシュ境界は geometry-only とする。**  
   episode ごとに可視 mask が変化するため、全ノードから選んだ top-K edge をそのまま episode 間で再利用してはいけない。静的 index は座標、trace ID、検索設定、sorted axis を保持し、可視・allowed mask を適用してから top-K を決める。

2. **disk cache と全 pair adjacency は今回の範囲外とする。**  
   まず run 内の index 再利用を実装し、計測後に必要性を判断する。

3. **AMP は明示設定でのみ有効にする。**  
   `training.mixed_precision` がない既存 config は従来どおり FP32 とする。fallback は行わず、非対応 device/dtype は明確に失敗させる。

4. **fanout は各 relation に独立して適用する同一整数とする。**  
   例: candidate K=8、`fanout_per_relation=3` なら、各 destination の各 active relation から最大3辺を一様・非復元抽出する。relation ごとに異なる fanout mapping は今回追加しない。

5. **sampling は closure 構築中に行う。**  
   full closure を作った後で edge を落とすのではなく、各 frontier の近傍を sampling してから次 hop を展開する。これにより node 数と edge 数の両方を減らす。

6. **prediction は変更しない。**  
   frozen prediction は全 candidate top-K を決定論的に使用し、AMP と edge sampling は学習だけに限定する。

7. **省略時は従来と同じ結果にする。**  
   `mixed_precision: off` かつ `edge_sampling` なしなら、graph plan、edge 順、loss、乱数系列を維持する。

## 実装順

| 順番 | ファイル | 対応項目 | 内容 |
|---:|---|---|---|
| 1 | `01_static_geometry_index.md` | 1 | visibility 非依存の静的 spatial index を抽出 |
| 2 | `02_run_lifetime_graph_cache.md` | 1 | trainer で index を一度だけ構築して episode 間再利用 |
| 3 | `03_amp_training.md` | 2 | 明示的 mixed precision と正しい gradient scaling |
| 4 | `04_target_subgraph_contract.md` | 3 | 既存 target-centered closure の契約固定と計測項目追加 |
| 5 | `05_relation_fanout_core.md` | 4 | pure NumPy の relation-wise fanout sampler |
| 6 | `06_relation_fanout_integration.md` | 4 | sampling を dependency expansion と設定へ接続 |
| 7 | `07_performance_metadata.md` | 横断 | 比較可能な速度・memory・subgraph 統計を run metadata に保存 |
| 8 | `08_ablation_validation.md` | 検証 | 旧互換、AMP、fanout を単独・段階的に実測 |

原則として1ファイルを1回の Codex 作業単位として、上から順に渡す。

## 完成後の設定例

```yaml
graph:
  neighbors_per_relation: 8
  neighbor_search: exact_index

training:
  mixed_precision: bf16
  edge_sampling:
    seed: 4201
    fanout_per_relation: 3
```

`bf16` は実行 GPU が対応するときだけ使用する。対応しない場合は `fp16` を明示する。`edge_sampling` を削除すれば sampling は無効になる。

## 全工程共通の受入条件

- query target は観測 context として使われない。
- hidden trace はどの hop でも sender にならない。
- `edge_index` を実際に縮小し、zero weight 化だけで済ませない。
- graph candidate K、relation radius、message-passing rounds、query batch、loss の意味を変更しない。
- sampling 無効時の exact-index と brute-force の既存同値性を維持する。
- formal study の既存 config と run を書き換えない。
- `ruff check .`、`ruff format --check .`、変更に直接関係する `pytest` を実行する。全 suite は要求しない。
