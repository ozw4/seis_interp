# Codex 実装プロンプト 04 — target-centered dependency subgraph の契約固定と step 計測


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 目的

現在すでに存在する target-centered L-hop dependency subgraph を作り直さず、学習高速化の基盤として契約を test で固定する。同時に、後続の fanout 効果を比較できる最小の per-step count/timing を training history に加える。

## 現在の前提

`FixedTraceGraphSubgraphBuilder.build(...)` と `build_trace_graph_subgraph(...)` は query IDs を seed とし、`model.message_passing_rounds` 分の incoming dependency closure を作る。plan の node ID は stable-ID 順、`query_indices` は query 入力順を保持する。

この工程で rectangular 4D block sampler や PyG subgraph loader を追加しない。既存 closure が、このモデルにおける geometry-aware local subgraph である。

## 主な対象

- `src/seis_interp/processing/trace_graph_subgraphs.py`
- `src/seis_interp/training/relational_trace_graph_poc_trainer.py`
- `tests/unit/test_trace_graph_subgraphs.py`
- `tests/unit/test_relational_trace_graph_trainer.py`

## 実装要件

### 1. subgraph invariants を test で固定する

少なくとも次を直接 test する。

1. query IDs が seed であり、loss target の順序は `query_indices` と一致する。
2. query trace は `observed_mask=False` で、sender にならない。
3. すべての sender は元の episode の visible/allowed domain に属する。
4. first hop は query への incoming edge、次 hop は前 hop で新規に発見した visible sender への incoming edgeである。
5. node は requested rounds の synchronous message passing に必要な closure だけである。
6. depth-L leaf は別経路で浅く到達しない限り余分に展開されない。
7. query の入力順と node の stable-ID 順が混同されない。
8. `edge_index` の local index、`edge_type`、distance、degree、minimum distance が整合する。
9. no-context query も空 graph として捨てず、query-only prediction/loss 対象に残る。
10. brute-force builder と exact-index builder の plan が sampling 無効時に一致する。

既存 test がすでに満たす項目は重複追加せず、欠けている契約だけ補う。

### 2. training history に subgraph count を追加する

既存 key を維持したまま、各 optimizer step の history entry に最低限次を追加する。

```text
subgraph_node_count
subgraph_support_node_count
subgraph_edge_count
subgraph_max_depth
batch_preparation_seconds
optimization_seconds
```

定義を固定する。

- `subgraph_node_count`: `len(plan.trace_ids)`
- `subgraph_support_node_count`: visible support node 数
- `subgraph_edge_count`: 実際に model へ渡す edge 数
- `subgraph_max_depth`: plan の実到達 max depth
- `batch_preparation_seconds`: query geometry、plan、model input、label materialization の時間
- `optimization_seconds`: zero-grad、forward、loss、backward、clip、optimizer step、loss/context scalar read の時間
- 既存 `seconds`: step 全体の wall-clock として残す

count は既存 `TraceGraphPlan.diagnostics` を正本として使い、同じ統計を別ロジックで再計算しない。必要なら diagnostics に不足する単純 count を追加するが、新しい stats class は作らない。

CUDA timing のためだけに各区間へ追加 `torch.cuda.synchronize()` を挿入しない。既存の scalar read が step 終端を同期する現在の性質を維持する。timing は絶対 benchmark ではなく相対比較用であることを docstring に記す。

### 3. trainer の可読性を維持する

計測追加で loop が読みにくくなる場合だけ、batch preparation または optimization を1責務の小さい private function に抽出する。汎用 callback framework や profiler abstraction は作らない。

## テスト要件

- 上記 subgraph invariants。
- 1〜2 step training smoke で新しい history key が存在し、count は非負、time は有限かつ非負。
- `subgraph_node_count == query_count + subgraph_support_node_count`。
- `subgraph_edge_count` が plan diagnostics と一致。
- 既存 `seconds`, `loss`, `query_count`, `no_context_query_count` が残る。
- sampling 無効時に graph plan の edge 配列・順序を変更しない。
- no-context query を含む trainer test。

wall-clock の大小関係や高速化率を unit test で assert しない。

## 非目標

- full-graph training mode
- random edge sampling
- static index cache の再設計
- AMP の再設計
- validation loop
- profiler dependency
- model architecture の変更

## 実行する確認

```bash
ruff check .
ruff format --check .
pytest   tests/unit/test_trace_graph_subgraphs.py   tests/unit/test_relational_trace_graph_trainer.py   tests/unit/test_relational_trace_graph_poc.py
```

## 受入条件

- 現在の target-only、target-centered、L-hop semantics が明示的な regression test で保護される。
- model に渡る実 node/edge 数を history から確認できる。
- 既存 default の numerical graph behavior は変わらない。
