# Codex 実装プロンプト 02 — run-lifetime graph index cache の trainer 接続


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 依存

`01_static_geometry_index.md` が完了し、visibility 非依存の静的 spatial index を複数 episode で共有できること。

## 目的

`train_relational_trace_graph_poc(...)` の一回の呼び出しにつき静的 spatial index を一度だけ構築し、episode ごとの `FixedTraceGraphSubgraphBuilder` から共有する。episode 固有 visibility と observed-neighbor cache は引き続き分離する。

## 主な対象

- `src/seis_interp/training/relational_trace_graph_poc_trainer.py`
- `src/seis_interp/processing/trace_graph_subgraphs.py`
- `src/seis_interp/processing/trace_graph_neighbors.py`
- `tests/unit/test_trace_graph_subgraphs.py`
- `tests/unit/test_relational_trace_graph_trainer.py`

実際の call site 名が変わっている場合は現在の code を優先する。

## 実装要件

### 1. static index を episode loop の外で構築する

`graph_settings.neighbor_search == "exact_index"` のとき、geometry 計算後かつ `while` episode loop の前に静的 spatial index を一度だけ作る。

概念上は次の形にする。

```python
geometry = compute_trace_graph_geometry(...)
spatial_index = TraceGraphSpatialIndex(...)

while training:
    episode = ...
    builder = FixedTraceGraphSubgraphBuilder.from_spatial_index(
        spatial_index,
        observed_mask=episode.visible_mask,
    )
```

実際の API は工程01で採用した設計へ合わせる。

`neighbor_search == "brute_force"` は現在の経路を維持する。

### 2. episode 固有状態を共有しない

episode ごとに新しく持つものは次。

- `visible_mask` および必要なら `allowed_mask`
- eligible sender 判定
- observed trace ごとの deterministic candidate-neighbor cache
- cache count/bytes diagnostics

次を episode 間で共有してはならない。

- visible/eligible mask
- visibility 適用後の top-K neighbor
- sampled edge（後続工程）
- query-specific initial edge

`FixedTraceGraphSubgraphBuilder` の docstring と `observed_neighbor_cache_info()` を現在の ownership に合わせて更新する。

### 3. 数値・順序を変えない

同じ seed、同じ query IDs、同じ visibility、同じ graph settings なら、変更前と同じ `TraceGraphPlan` を返すこと。特に `trace_ids`、`query_indices`、`edge_index`、`edge_type`、distance、degree、minimum distance、depth、diagnostics の意味を変えない。

この工程では設定 key を追加しない。`exact_index` を選んだ既存 config が自動的に run-lifetime reuse を受ける形とする。

### 4. 小さい責務に保つ

pipeline に search implementation を置かない。trainer は object を一度作り builder に渡す orchestration だけにする。factory registry、global singleton、process cache は作らない。

## テスト要件

最低限、次を追加・更新する。

1. 2 episode 以上を開始する小さい training fixture で、静的 spatial index の構築が一回だけであること。
2. builder は episode ごとに別であり、異なる visibility が混ざらないこと。
3. episode 1 で cache した observed neighbor が episode 2 の hidden sender として流用されないこと。
4. 共有 index 経由と従来 constructor 経由の `TraceGraphPlan` が一致すること。
5. `brute_force` 経路が変更されていないこと。
6. training smoke が規定 step を完了し、finite loss を返すこと。
7. query target と hidden trace が sender にならないこと。

constructor 回数の確認は、公開 API に test 専用 counter を追加せず monkeypatch/spy など既存 test 方針に合う方法で行う。

## 非目標

- disk への index 保存
- process をまたぐ cache
- candidate edge の sampling
- AMP
- model、loss、checkpoint payload の変更
- performance threshold の test 化

## 実行する確認

```bash
ruff check .
ruff format --check .
pytest   tests/unit/test_trace_graph_spatial_index.py   tests/unit/test_trace_graph_subgraphs.py   tests/unit/test_relational_trace_graph_trainer.py
```

現在の test 名が異なる場合は、変更した実装と immediate dependent を対象に置き換える。

## 受入条件

- exact-index の静的 geometry/search structure は training call あたり一度だけ構築される。
- episode 固有 visibility と neighbor cache は共有されない。
- sampling 無効・FP32 の既存 graph plan と training semantics は不変。
- persistent cache や全 adjacency は追加されていない。
