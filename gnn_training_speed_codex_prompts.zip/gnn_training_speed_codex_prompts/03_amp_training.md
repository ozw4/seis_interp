# Codex 実装プロンプト 03 — AMP を用いた明示的 mixed-precision training


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 目的

Relational Trace GNN の PoC training に opt-in AMP を追加する。既存 config は省略時 FP32 のまま動き、relative loss は FP32 で計算する。prediction は変更しない。

## 主な対象

- `src/seis_interp/relational_trace_graph_poc_config.py`
- 必要な場合のみ `src/seis_interp/relational_trace_graph_config.py`
- `src/seis_interp/training/relational_trace_graph_poc_trainer.py`
- 責務分離が必要なら `src/seis_interp/training/mixed_precision.py`
- `src/seis_interp/pipelines/interpolate_relational_trace_graph.py`
- 関連 config/trainer/checkpoint tests

## 設定契約

`training` に optional key を追加する。

```yaml
training:
  mixed_precision: off   # off | fp16 | bf16
```

- key がない場合は `"off"`。
- `"off"`, `"fp16"`, `"bf16"` 以外は config validation で拒否する。
- この工程では `enabled` boolean や別の scaler 設定を追加しない。
- device が CUDA でないときの `"fp16"`/`"bf16"` は明確な error とする。
- `bf16` 非対応 CUDA で `"bf16"` を指定した場合も error とする。
- dtype を自動変更・fallback しない。

設定 validator が複数ある場合、実際に同じ trainer を起動する入口だけを一貫して更新する。未使用の一般化はしない。

## 実装要件

### 1. PyTorch 2.2 以上の宣言範囲を守る

`pyproject.toml` の `torch>=2.2` を暗黙に引き上げない。その範囲で利用できる `autocast`/`GradScaler` API を使う。version 分岐の compatibility layer は作らない。

### 2. forward だけを autocast 対象にする

概念的には次とする。

```python
with autocast_context:
    prediction, context = model(batch)

objective = masked_trace_loss(
    prediction.float(),
    target.float(),
    loss_name=loss,
)
```

`masked_trace_relative_mse` の分母・reduction を low precision にしない。shape validation と finite validation も維持する。

`mixed_precision == "off"` では unnecessary autocast wrapper を通さず、従来の FP32 path を保つ。

### 3. scaler と gradient clipping の順序を正しくする

- `fp16`: enabled GradScaler を使う。
- `bf16`: scaler を使わない、または disabled scaler とする。
- `off`: 従来の backward/step。
- gradient clipping がある場合、fp16 では `unscale_(optimizer)` の後に `clip_grad_norm_` を呼ぶ。
- non-finite gradient/loss の既存 error contract を弱めない。
- `optimizer.zero_grad(set_to_none=True)` を維持する。

scaler state の checkpoint/resume は今回不要。現在の PoC は final model を保存し、途中 resume を提供していないため、将来用 checkpoint machinery は追加しない。

### 4. 乱数と prediction を変えない

AMP mode は episode generator や model initialization seed を消費してはならない。`predict_relational_trace_graph(...)` は FP32 のままにする。

run の resolved config に mode が残ること。checkpoint の推論に mixed precision 設定を要求しない。

## テスト要件

1. missing key が `"off"` に解決される。
2. accepted values と invalid values。
3. CPU + `off` training smoke が従来どおり finite loss で完了する。
4. CPU + `fp16`/`bf16` が明確に失敗する。
5. CUDA が利用可能な test 環境では、対応 dtype の1〜2 step smoke を `skipif` 付きで実行し、finite loss/parameter を確認する。
6. fp16 + gradient clipping で unscale が clipping より先になること。private implementation detail へ過度に結合せず、必要なら小さい helper を直接 test する。
7. `off` の同一 seed で query sequence と loss history が変更前と一致する。
8. prediction call に AMP 設定が流入しない。
9. strict config key tests と既存 study config tests を更新する。

AMP の loss 値を FP32 と完全一致させる test は書かない。

## 非目標

- prediction AMP
- gradient accumulation
- compile
- distributed training
- scaler checkpoint
- dtype auto-selection
- edge sampling
- model architecture の変更

## 実行する確認

```bash
ruff check .
ruff format --check .
pytest   tests/unit/test_relational_trace_graph_config.py   tests/unit/test_relational_trace_graph_poc.py   tests/unit/test_relational_trace_graph_trainer.py   tests/unit/test_relational_trace_graph_prediction.py   tests/unit/test_relational_trace_graph_checkpoints.py
```

存在する immediate config-fixture tests も必要な範囲で追加する。

## 受入条件

- 既存 config は FP32 で同じ挙動をする。
- `fp16` は scaler、unscale、clip、step の正しい順序を使う。
- loss は FP32。
- unsupported mode/device は silent fallback せず失敗する。
- prediction と checkpoint 推論契約は変わらない。
