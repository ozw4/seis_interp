# Codex 検証プロンプト 08 — static cache / AMP / fanout の段階的 ablation


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 性質

この工程は原則としてコード変更ではなく、工程01〜07の受入検証である。欠陥を発見した場合は、無関係な最適化を加えず、原因を特定して該当工程の最小修正だけを行う。

既存の formal study config、run directory、採用結果を変更しない。smoke/速度結果を model 選択や論文性能値として使わない。

## 目的

同じ入力、model、seed、optimizer、loss、query batch、step 数で次を比較する。

| Variant | Static index reuse | Mixed precision | Edge sampling |
|---|---:|---|---|
| A | 有効 | `off` | なし |
| B | 有効 | `fp16` または `bf16` | なし |
| C | 有効 | Bと同じ | `fanout_per_relation: 3` |
| D | 有効 | `off` | `fanout_per_relation: 3` |

A は新実装の互換 baseline。工程開始前に参照 commit の計測値が残っている場合は A と比較する。残っていない場合、旧 commit の速度比較だけを目的に working tree を壊して checkout しない。必要なら一時 `git worktree` を使うが、graph plan exact-parity は unit test を正本とし、旧実行を必須にはしない。

## 条件固定

現在採用している relational-trace-graph の smoke config を一時 copy して使う。formal YAML を編集しない。

全 variant で次を固定する。

- model constructor
- model initialization seed
- episode seed
- edge seed（sampling variant 間）
- loss
- Global RMS normalization
- optimizer、learning rate、weight decay、gradient clipping
- inner mask fraction
- max steps
- query batch size
- graph relation scales、radius、candidate K
- message-passing rounds
- device
- input case/volume/mask
- process/thread 環境

速度計測には2-step smoke を使わない。同一 max steps で最低200 updatesを目安にし、GPU memory/runtime 制約がある場合でも全 variant の step 数を同じにする。最初の20 stepは warm-up として、history の step 21以降から median/mean step time も別途計算する。repository code に warm-up feature を追加せず、run metadata/history を後処理する。

GPU は同じ physical device を使い、variant を別 process で逐次実行する。並列実行しない。実行前に他 process の GPU 使用状況を確認する。

mixed precision dtype は device capability を事前確認して一つに固定する。対応していない mode へ自動 fallback しない。

## 一時 config の差分

A:

```yaml
training:
  mixed_precision: off
  # edge_sampling keyなし
```

B:

```yaml
training:
  mixed_precision: bf16  # 対応GPUの場合。そうでなければ全比較でfp16を明示
  # edge_sampling keyなし
```

C:

```yaml
training:
  mixed_precision: bf16
  edge_sampling:
    seed: 4201
    fanout_per_relation: 3
```

D:

```yaml
training:
  mixed_precision: off
  edge_sampling:
    seed: 4201
    fanout_per_relation: 3
```

元 config の `graph.neighbors_per_relation` は candidate K として変更しない。

## 実行前 checks

```bash
git status --short
ruff check .
ruff format --check .
pytest   tests/unit/test_trace_graph_spatial_index.py   tests/unit/test_trace_graph_edge_sampling.py   tests/unit/test_trace_graph_subgraphs.py   tests/unit/test_relational_trace_graph_config.py   tests/unit/test_relational_trace_graph_trainer.py   tests/unit/test_relational_trace_graph_prediction.py
```

実在する file 名に合わせて調整する。

## 各 run から抽出する値

最低限、次を表にする。

```text
status
steps_completed
training_seconds
optimizer_updates_per_second
mean/median recorded step seconds
mean batch_preparation_seconds
mean optimization_seconds
mean/max subgraph_node_count
mean/max subgraph_edge_count
training peak CUDA allocated/reserved bytes
initial loss
final loss
finite-loss status
prediction coverage
```

C/D について、candidate K と effective F も併記する。

## 判定

### Correctness

- A は fixed seed で安定して完了する。
- A の graph-plan parity unit tests は exact。
- B/C/D は non-finite loss/gradient を出さない。
- 全 variant で query count、target coverage、prediction shape、observed exact reinsertion の既存契約を満たす。
- sampling variant でも prediction diagnostics は full candidate K の決定論的 inference である。

### Speed

ハードコードした合格率を設けない。次を観察して bottleneck を分類する。

- Aで batch preparation が大きい: graph/index/subgraph path が主要。
- Aで optimization が大きい: model/trace codec/message passing が主要。
- Bで optimization のみ短縮: AMP が期待どおり。
- C/Dで node/edge と batch/optimization が短縮: fanout が期待どおり。
- edge は減るが時間が減らない: Python sampling/assembly overhead または model の node-side cost を疑う。
- static index 後も episode setup が支配的: 次の最適化候補としてのみ記録し、この工程で disk cache を追加しない。

smoke loss や test target metric を見て fanout/dtype を選ばない。これは速度・安定性の受入であり、最終精度は別の validation study で評価する。

## 最終報告

次の形式で、実測値を省略せず報告する。

```text
Environment:
- commit
- device / torch / CUDA
- fixed config source
- updates and query batch

Results:
| Variant | updates/s | prep s | optim s | nodes | edges | peak mem | finite |

Correctness:
- exact-parity tests
- coverage / prediction contract
- AMP/fanout errors

Conclusion:
- 主ボトルネック
- 採用してよい runtime change
- 精度 validation が必要な behavior change
- 今回は行わない次候補
```

数値が期待と異なっても隠さず、そのまま報告する。新しい最適化を追加して結果を作り直さない。
