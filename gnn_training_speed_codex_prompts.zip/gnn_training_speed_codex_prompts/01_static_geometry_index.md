# Codex 実装プロンプト 01 — visibility 非依存の静的 geometry index


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 目的

`FixedTraceGraphNeighborIndex` が episode ごとに geometry、trace ID、sorted coordinate axis を再構築している部分を分離し、visibility に依存しない静的 spatial index を導入する。この工程では trainer への接続は行わない。

## 現在の主な対象

- `src/seis_interp/processing/trace_graph_neighbors.py`
- `tests/unit/test_trace_graph_neighbors.py`
- `tests/unit/test_trace_graph_spatial_index.py`

現在の `FixedTraceGraphNeighborIndex` は geometry、trace IDs、検索設定、`observed_mask` を所有し、eligible row だけから sorted axis を作る。公開されている既存 constructor と `select(...)` の挙動は壊さない。

## 実装要件

### 1. geometry-only index を追加する

責務が明確な名前、例えば `TraceGraphSpatialIndex` を用い、次だけを所有させる。

- immutable/read-only copy の candidate geometry
- immutable/read-only copy の candidate trace IDs
- validation 済みの検索設定
- relation search に必要な全 candidate row の sorted coordinate axes
- distance 計算に必要な scale

この object は `observed_mask` と `allowed_mask` を所有してはならない。

配置は既存責務に従う。`trace_graph_neighbors.py` 内で小さく収まるなら分割しない。独立 module が明確に必要なら `trace_graph_spatial_index.py` のような責務固有名を使う。

### 2. visibility 適用後に top-K を決定する

静的 index で box candidate を求めた後、episode 固有の eligibility を適用し、その後に self 除外、radius 判定、distance/trace-ID 順の top-K を行う。

次の誤実装は禁止する。

```text
all candidates -> top-K cache -> visible filter
```

これは hidden nearest neighbor が top-K を占有したとき、さらに遠い visible neighbor を取り戻せないため不正確である。

正しい順序は次とする。

```text
geometry box candidates
    -> visible & allowed filter
    -> self exclusion
    -> exact distance/radius
    -> distance then trace-ID top-K
```

### 3. 既存 API を維持する

`FixedTraceGraphNeighborIndex(...)` の既存 constructor と `select(...)` を使う call site がそのまま動くこと。内部で新しい静的 index を構築してよい。

後続工程が共有 index を渡せる最小 API を追加する。例えば classmethod や optional keyword を使えるが、同じロジックを二重実装しない。

共有 index と episode visibility の組み合わせが不整合な場合は、曖昧に継続せず明確な `ValueError` とする。hash registry や汎用 cache manager は作らない。

### 4. exact semantics を維持する

少なくとも次を保持する。

- destination 入力順
- relation 順
- distance、次に sender trace ID の tie-break
- `int64` IDs/relation type、`float64` distance
- radius-inclusive 判定
- self edge 除外
- `excluded_relation`
- 既存の `single_4d` 挙動
- 入力配列を変更しないこと

## テスト要件

既存 brute-force `select_trace_graph_neighbors(...)` を oracle として、静的 index 経由の結果が全 array で完全一致することを確認する。

最低限、次を含める。

1. 複数の異なる `observed_mask`
2. `allowed_mask` あり/なし
3. hidden nearest candidate の後ろに visible candidate が存在するケース
4. distance tie
5. empty eligible set
6. `multi_relation`
7. 既存 `single_4d` の regression
8. 共有 index の geometry/ID 配列が外部変更で変化しないこと
9. episode view を複数作っても visibility が相互汚染しないこと

performance の絶対時間を unit test で assert しない。

## 非目標

- trainer や subgraph builder への共有 index 接続
- disk cache
- 全 pair adjacency
- edge sampling
- AMP
- config key の追加

## 実行する確認

```bash
ruff check .
ruff format --check .
pytest tests/unit/test_trace_graph_neighbors.py tests/unit/test_trace_graph_spatial_index.py
```

`test_trace_graph_spatial_index.py` が現在存在しない場合だけ新規作成する。存在するならそこへ集約する。

## 受入条件

- 静的 index は visibility/allowed mask 非依存である。
- 既存 `FixedTraceGraphNeighborIndex` の利用方法が壊れない。
- visibility を適用してから top-K を選ぶ。
- brute-force と exact に同じ edge arrays を返す。
- 後続工程で同じ静的 index を複数 episode に渡せる。
