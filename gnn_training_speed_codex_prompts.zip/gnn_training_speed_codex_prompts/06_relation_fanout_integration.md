# Codex 実装プロンプト 06 — fixed fanout を dependency expansion と training config へ接続


## 作業開始前の共通指示

対象リポジトリは `ozw4/seis_interp`。参照時点は `main@5829a11482edd8adafd29b4be25f910fe5545425` だが、実装時は現在の `HEAD` を正本とする。

1. リポジトリ root で `AGENTS.md` と `docs/repository_layout.md` を読む。
2. `git status --short` を確認し、利用者の未コミット変更や無関係な変更を破棄しない。
3. 対象コードと直接関係するテストを先に読む。参照時点から実装済みの箇所が増えていたら、重複実装せず現在の設計へ適合させる。
4. このプロンプトの範囲だけを実装する。後続工程を先回りしない。
5. 新しい外部依存、PyTorch Geometric、`schema_version`、汎用 `utils.py`、将来用途だけの抽象化は追加しない。
6. 明示がない限り既存 CLI、設定、省略時の挙動、配列順序、乱数系列、checkpoint の推論契約を維持する。
7. コミットは要求されていない。実装、テスト、差分説明まで行い、勝手に commit しない。

## 完了時の報告形式

次を簡潔に報告すること。

- 変更したファイル
- 実装した契約
- 実行したコマンドと結果
- 残る制約または、後続工程へ渡す注意点


## 依存

- run-lifetime static index reuse が完了している。
- `05_relation_fanout_core.md` の pure NumPy sampler が存在する。
- target-centered closure の regression tests が存在する。

## 目的

学習時だけ、各 destination の各 active relation から最大 F candidate edge を毎 optimizer step ランダム抽出する。sampling は dependency closure の各 hop を展開する前に行い、node と edge の両方を減らす。

## 設定契約

`training` に optional nested mapping を追加する。

```yaml
training:
  edge_sampling:
    seed: 4201
    fanout_per_relation: 3
```

契約は次。

- `edge_sampling` がない場合は完全に無効。
- mapping の exact keys は `seed`, `fanout_per_relation`。
- `seed`: bool ではない nonnegative integer。
- `fanout_per_relation`: positive integer。
- `fanout_per_relation <= graph.neighbors_per_relation`。
- 今回は `graph.topology == "multi_relation"` のみ対応。
- 今回は `graph.neighbor_search == "exact_index"` のみ対応。
- 条件を満たさない設定は validation 時に明確に拒否する。
- `enabled` flag、relation-name mapping、candidate-pool key は追加しない。

`graph.neighbors_per_relation` は visibility 適用後に作る deterministic candidate K、`training.edge_sampling.fanout_per_relation` はそこから実際に使う F とする。

## 実装要件

### 1. episode RNG と独立した generator を作る

trainer 呼び出しにつき edge sampling 専用に次を一度だけ作る。

```python
edge_rng = np.random.default_rng(edge_sampling["seed"])
```

これは model initialization、episode mask、query batching の RNG と共有しない。edge sampling を有効化しても episode ID、hidden query IDs、query order は変化してはならない。

各 `build(...)` 内で generator を再 seed しない。training step が進むたび generator state を進め、同じ candidate set でも再 sampling されるようにする。

### 2. closure 展開前に sampling する

sampling を適用する場所は次。

- query destinations の initial incoming candidates
- 2 hop 以降に展開される observed destination の incoming candidates

各 hop で、sampled sender だけを `next_frontier` へ加える。full closure を作った後で edge だけ削除してはいけない。

`FixedTraceGraphSubgraphBuilder` の episode cache は deterministic candidate neighbors を保持する。sampled subset を episode cache に保存してはいけない。したがって、

```text
static geometry index: run lifetime
candidate neighbor cache: episode lifetime
sampled subset: one build / optimizer-step lifetime
```

とする。

### 3. plan coverage normalization を揃える

sampling 有効時の `TraceGraphPlan.neighbors_per_relation` は F とし、`coverage = degree / F` となるようにする。candidate K のままにして dense sampled relation を常に `F/K` と表現し、prediction 時だけ1へ跳ねる train/inference shift を作らない。

candidate K は diagnostics または run config から追跡できるため、model input の coverage denominator と混同しない。

### 4. sampling 無効時を完全互換にする

`edge_sampling is None` では sampler を呼ばず、既存 edge arrays、node closure、diagnostics、loss、episode RNG sequence を維持する。

### 5. prediction を変更しない

`predict_relational_trace_graph(...)`、checkpoint load、frozen inference には `edge_sampling` を渡さない。prediction は graph の full deterministic candidate K を使い、plan denominator も K とする。

### 6. 設定と provenance

実際に trainer を起動する config validator を更新する。strict exact-key test を維持する。resolved config には nested mapping がそのまま残る。

checkpoint の model constructor や graph settings に training-only fanout を入れない。provenance metadata への追加は後続工程07で行う。

## テスト要件

1. config absence で disabled。
2. valid mapping と、unknown/missing key、bool seed、negative seed、invalid F。
3. `F > K`、non-multi-relation、non-exact-index の rejection。
4. sampling 無効時の plan が変更前と array 完全一致。
5. 各 hop の各 `(destination, relation)` edge 数が F 以下。
6. sampled sender だけが次 frontier/node set に現れること。
7. hidden/query trace が sender にならないこと。
8. candidate cache の edge count は full candidate の count で、sampled count に縮まらないこと。
9. same model seed + episode seed + edge seed で query sequence、sampled graph、loss history が再現すること。
10. edge seed だけを変えると query sequence は同じで、候補が十分ある step の sampled graph は変わること。
11. step が変わると同じ destination candidate でも再 sampling されること。
12. history の `subgraph_node_count` と `subgraph_edge_count` が実際に縮小する fixture。
13. prediction regression は full K かつ deterministic。
14. 1〜2 step CPU training smoke。AMP は off でよい。

異なる seed で必ず loss が変わることは assert しない。sampled edge ID を直接確認する。

## 非目標

- brute-force sampling 対応
- single-4D sampling
- relation ごとの異なる F
- adaptive/learned sampling
- distance-weighted sampling
- validation/test graph の sampling
- model architecture の変更

## 実行する確認

```bash
ruff check .
ruff format --check .
pytest   tests/unit/test_trace_graph_edge_sampling.py   tests/unit/test_trace_graph_subgraphs.py   tests/unit/test_relational_trace_graph_config.py   tests/unit/test_relational_trace_graph_poc.py   tests/unit/test_relational_trace_graph_trainer.py   tests/unit/test_relational_trace_graph_prediction.py   tests/unit/test_relational_trace_graph_checkpoints.py
```

関連する strict study-config test が失敗する場合、既存 config へ不要な key を足すのではなく optional default を正しく扱う。

## 受入条件

- actual `edge_index` と closure node 数が減る。
- relation ごとの最大 F が守られる。
- mask/query RNG と edge RNG が独立している。
- disabled path と prediction path は従来の full deterministic K。
- sampled subset は step ごとに再抽出される。
